"""Agricultural data loading, validation, and demonstration data."""

from __future__ import annotations

import re

import numpy as np
import pandas as pd

REQUIRED_COLUMNS = ("state", "crop", "year", "area_ha", "production_tonnes")
OPTIONAL_COLUMNS = ("season", "yield_tonnes_per_ha")

COLUMN_ALIASES = {
    "state": "state",
    "state_name": "state",
    "state_ut": "state",
    "crop": "crop",
    "crop_name": "crop",
    "commodity": "crop",
    "season": "season",
    "season_name": "season",
    "year": "year",
    "crop_year": "year",
    "year_of_production": "year",
    "area": "area_ha",
    "area_ha": "area_ha",
    "area_hectare": "area_ha",
    "area_hectares": "area_ha",
    "production": "production_tonnes",
    "production_tonnes": "production_tonnes",
    "production_tons": "production_tonnes",
    "yield": "yield_tonnes_per_ha",
    "yield_tonnes_per_ha": "yield_tonnes_per_ha",
    "yield_tons_per_hectare": "yield_tonnes_per_ha",
}


def _normalized_column_name(value: object) -> str:
    return re.sub(r"[^a-z0-9]+", "_", str(value).strip().lower()).strip("_")


def normalize_dataset(frame: pd.DataFrame) -> tuple[pd.DataFrame, list[str]]:
    """Normalize common CSV schemas and return canonical records plus warnings."""
    if frame.empty:
        raise ValueError("The uploaded CSV has no data rows.")

    renamed = {}
    for column in frame.columns:
        normalized = _normalized_column_name(column)
        if normalized in COLUMN_ALIASES:
            renamed[column] = COLUMN_ALIASES[normalized]

    data = frame.rename(columns=renamed).copy()
    data = data.loc[:, ~data.columns.duplicated()]
    missing = [column for column in REQUIRED_COLUMNS if column not in data.columns]
    if missing:
        expected = "state, crop, year, area, and production (or an equivalent recognized name)"
        raise ValueError(f"Missing required columns: {', '.join(missing)}. Expected {expected}.")

    data["state"] = data["state"].astype("string").str.strip()
    data["crop"] = data["crop"].astype("string").str.strip()
    if "season" not in data.columns:
        data["season"] = "Not recorded"
    else:
        data["season"] = data["season"].fillna("Not recorded").astype("string").str.strip()
        data.loc[data["season"].eq(""), "season"] = "Not recorded"

    for column in ("year", "area_ha", "production_tonnes", "yield_tonnes_per_ha"):
        if column in data.columns:
            values = data[column].astype("string").str.replace(",", "", regex=False)
            data[column] = pd.to_numeric(values, errors="coerce")

    if "yield_tonnes_per_ha" not in data.columns:
        data["yield_tonnes_per_ha"] = np.nan
    derived = data["yield_tonnes_per_ha"].isna() & data["area_ha"].gt(0)
    data.loc[derived, "yield_tonnes_per_ha"] = (
        data.loc[derived, "production_tonnes"] / data.loc[derived, "area_ha"]
    )

    warnings = []
    before = len(data)
    data = data.dropna(subset=["state", "crop", "year", "area_ha", "production_tonnes"])
    data = data.loc[
        data["state"].ne("")
        & data["crop"].ne("")
        & data["area_ha"].gt(0)
        & data["production_tonnes"].ge(0)
        & data["year"].between(1900, 2100)
    ].copy()
    if len(data) < before:
        warnings.append(f"Removed {before - len(data):,} rows with missing or invalid required values.")
    duplicates = int(data.duplicated().sum())
    if duplicates:
        warnings.append(f"Found {duplicates:,} duplicate rows; duplicates were retained in the analysis.")
    if data.empty:
        raise ValueError("No valid rows remain after checking required fields and numeric values.")

    data["year"] = data["year"].astype(int)
    data["yield_tonnes_per_ha"] = pd.to_numeric(data["yield_tonnes_per_ha"], errors="coerce")
    data = data.sort_values(["year", "state", "crop", "season"]).reset_index(drop=True)
    return data, warnings


def make_demo_data() -> pd.DataFrame:
    """Return deterministic synthetic records for UI and workflow demonstration only."""
    rng = np.random.default_rng(2026)
    states = [
        "Andhra Pradesh", "Assam", "Bihar", "Chhattisgarh", "Gujarat", "Haryana",
        "Himachal Pradesh", "Jharkhand", "Karnataka", "Kerala", "Madhya Pradesh",
        "Maharashtra", "Odisha", "Punjab", "Rajasthan", "Tamil Nadu", "Telangana",
        "Uttar Pradesh", "Uttarakhand", "West Bengal",
    ]
    crops = {"Rice": (2.8, "Kharif"), "Wheat": (3.4, "Rabi"), "Maize": (2.6, "Kharif"), "Cotton": (0.55, "Kharif")}
    years = range(2014, 2025)
    records = []
    state_factor = {state: rng.uniform(0.72, 1.32) for state in states}
    for state in states:
        for crop, (base_yield, season) in crops.items():
            for year in years:
                area = rng.uniform(35_000, 450_000) * state_factor[state]
                trend = 1 + (year - 2014) * rng.uniform(-0.004, 0.018)
                yield_value = max(0.08, base_yield * state_factor[state] * trend + rng.normal(0, base_yield * 0.11))
                production = area * yield_value
                records.append({
                    "state": state,
                    "crop": crop,
                    "season": season,
                    "year": year,
                    "area_ha": round(area, 1),
                    "production_tonnes": round(production, 1),
                    "yield_tonnes_per_ha": round(production / area, 5),
                })
    return pd.DataFrame.from_records(records)