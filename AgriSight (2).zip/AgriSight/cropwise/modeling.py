"""Leakage-aware yield model evaluation and scenario estimation."""

from __future__ import annotations

import math

import numpy as np
import pandas as pd
from sklearn.compose import ColumnTransformer
from sklearn.dummy import DummyRegressor
from sklearn.ensemble import RandomForestRegressor
from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import OneHotEncoder, StandardScaler

CATEGORICAL_FEATURES = ["state", "crop", "season"]
NUMERIC_FEATURES = ["year", "area_ha"]
FEATURES = CATEGORICAL_FEATURES + NUMERIC_FEATURES
TARGET = "yield_tonnes_per_ha"


def _pipeline(regressor: object, scale_numeric: bool = False) -> Pipeline:
    numeric_steps = [("scale", StandardScaler())] if scale_numeric else []
    numeric = Pipeline(numeric_steps) if numeric_steps else "passthrough"
    preprocessing = ColumnTransformer(
        [
            ("category", OneHotEncoder(handle_unknown="ignore"), CATEGORICAL_FEATURES),
            ("numeric", numeric, NUMERIC_FEATURES),
        ]
    )
    return Pipeline([("features", preprocessing), ("regressor", regressor)])


def evaluate_models(data: pd.DataFrame) -> dict:
    """Compare baseline, linear regression, and random forest on held-out time."""
    usable = data.dropna(subset=FEATURES + [TARGET]).copy()
    usable = usable.loc[usable[TARGET].ge(0)]
    if len(usable) < 8:
        raise ValueError("At least 8 valid rows with yield values are required for model evaluation.")

    years = np.sort(usable["year"].unique())
    if len(years) >= 3:
        test_year_count = max(1, math.ceil(len(years) * 0.2))
        test_years = years[-test_year_count:]
        train = usable.loc[~usable["year"].isin(test_years)]
        test = usable.loc[usable["year"].isin(test_years)]
        split_note = f"Chronological holdout: trained through {int(train['year'].max())}; tested on {', '.join(map(str, test_years.astype(int)))}."
    else:
        # A chronological holdout is not meaningful with fewer than three years.
        train = usable.iloc[:-max(1, len(usable) // 5)]
        test = usable.iloc[len(train):]
        split_note = "Random holdout used because the dataset contains fewer than three distinct years; this is not a forecasting validation."

    if train.empty or test.empty:
        raise ValueError("The available data cannot form a non-empty train/test split.")

    x_train, y_train = train[FEATURES], train[TARGET]
    x_test, y_test = test[FEATURES], test[TARGET]
    candidates = {
        "Median baseline": _pipeline(DummyRegressor(strategy="median")),
        "Linear regression": _pipeline(LinearRegression(), scale_numeric=True),
        "Random forest": _pipeline(
            RandomForestRegressor(n_estimators=160, min_samples_leaf=2, random_state=42, n_jobs=-1)
        ),
    }
    metrics = []
    predictions = test[["state", "crop", "season", "year", "yield_tonnes_per_ha"]].copy()
    predictions = predictions.rename(columns={TARGET: "actual"})
    fitted = {}

    for name, estimator in candidates.items():
        estimator.fit(x_train, y_train)
        predicted = np.maximum(estimator.predict(x_test), 0)
        predictions[name] = predicted
        metrics.append({
            "Model": name,
            "MAE (t/ha)": mean_absolute_error(y_test, predicted),
            "RMSE (t/ha)": np.sqrt(mean_squared_error(y_test, predicted)),
            "R²": r2_score(y_test, predicted) if len(y_test) > 1 else np.nan,
        })
        fitted[name] = estimator

    full_models = {
        "Linear regression": _pipeline(LinearRegression(), scale_numeric=True),
        "Random forest": _pipeline(
            RandomForestRegressor(n_estimators=160, min_samples_leaf=2, random_state=42, n_jobs=-1)
        ),
    }
    for estimator in full_models.values():
        estimator.fit(usable[FEATURES], usable[TARGET])

    metric_frame = pd.DataFrame(metrics)
    eligible = metric_frame.loc[metric_frame["Model"].ne("Median baseline")]
    best_name = str(eligible.sort_values("MAE (t/ha)").iloc[0]["Model"])
    return {
        "metrics": metric_frame,
        "predictions": predictions.reset_index(drop=True),
        "models": full_models,
        "best_model": best_name,
        "split_note": split_note,
        "rows_used": len(usable),
        "features": FEATURES,
    }


def estimate_yield(results: dict, state: str, crop: str, season: str, year: int, area_ha: float) -> float:
    """Estimate yield for a user-defined scenario using the selected fitted model."""
    if area_ha <= 0:
        raise ValueError("Cultivated area must be greater than zero.")
    row = pd.DataFrame([{
        "state": state,
        "crop": crop,
        "season": season,
        "year": int(year),
        "area_ha": float(area_ha),
    }])
    prediction = results["models"][results["best_model"]].predict(row[FEATURES])[0]
    return max(0.0, float(prediction))