const PALETTE = ["#285642", "#bd6948", "#8b9f55", "#527a88", "#d2a44b", "#846f8a", "#63957f", "#b17d4f"];
const state = {
  records: [],
  source: "",
  isDemo: true,
  rawUpload: null,
  uploadWarnings: [],
  modelResults: null,
  page: "overview",
  selectedStates: new Set(),
  selectedCrops: new Set(),
  selectedSeasons: new Set(),
  startYear: null,
  endYear: null,
};

const $ = (selector) => document.querySelector(selector);
const $$ = (selector) => [...document.querySelectorAll(selector)];
const number = new Intl.NumberFormat("en-IN", { maximumFractionDigits: 0 });
const decimal = new Intl.NumberFormat("en-IN", { maximumFractionDigits: 2 });
const escapeHtml = (value) => String(value ?? "").replace(/[&<>"']/g, (char) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[char]);

function showError(message) {
  const box = $("#app-error");
  box.textContent = message;
  box.hidden = !message;
}

async function requestJson(url, options) {
  const response = await fetch(url, options);
  const payload = await response.json();
  if (!response.ok) throw new Error(payload.detail || `Request failed (${response.status}).`);
  return payload;
}

function unique(field) {
  return [...new Set(state.records.map((row) => row[field]).filter((value) => value !== null && value !== undefined && value !== ""))].sort((a, b) => String(a).localeCompare(String(b), undefined, { numeric: true }));
}

function resetSelection() {
  state.selectedStates = new Set(unique("state"));
  state.selectedCrops = new Set(unique("crop"));
  state.selectedSeasons = new Set(unique("season"));
  const years = state.records.map((row) => Number(row.year)).filter(Number.isFinite);
  state.startYear = Math.min(...years);
  state.endYear = Math.max(...years);
  state.modelResults = null;
  renderFilterControls();
}

function renderCheckList(containerId, values, selected, key) {
  const container = $(`#${containerId}`);
  container.innerHTML = values.map((value, index) => {
    const id = `${key}-${index}`;
    return `<label class="check-option" for="${id}"><input id="${id}" type="checkbox" value="${escapeHtml(value)}" ${selected.has(value) ? "checked" : ""}><span>${escapeHtml(value)}</span></label>`;
  }).join("");
  container.onchange = (event) => {
    const input = event.target.closest("input[type=checkbox]");
    if (!input) return;
    const value = input.value;
    if (input.checked) selected.add(value);
    else selected.delete(value);
    refresh();
  };
}

function renderFilterControls() {
  renderCheckList("state-filters", unique("state"), state.selectedStates, "state");
  renderCheckList("crop-filters", unique("crop"), state.selectedCrops, "crop");
  renderCheckList("season-filters", unique("season"), state.selectedSeasons, "season");
  const min = Math.min(...state.records.map((row) => Number(row.year)));
  const max = Math.max(...state.records.map((row) => Number(row.year)));
  const start = $("#year-start");
  const end = $("#year-end");
  [start, end].forEach((slider) => { slider.min = min; slider.max = max; });
  start.value = state.startYear ?? min;
  end.value = state.endYear ?? max;
  start.oninput = () => {
    state.startYear = Math.min(Number(start.value), state.endYear);
    if (Number(start.value) > state.endYear) start.value = state.endYear;
    refresh();
  };
  end.oninput = () => {
    state.endYear = Math.max(Number(end.value), state.startYear);
    if (Number(end.value) < state.startYear) end.value = state.startYear;
    refresh();
  };
  updateYearOutput();
}

function updateYearOutput() {
  $("#year-output").textContent = `${state.startYear}–${state.endYear}`;
}

function selectedRecords() {
  return state.records.filter((row) => state.selectedStates.has(row.state)
    && state.selectedCrops.has(row.crop)
    && state.selectedSeasons.has(row.season)
    && Number(row.year) >= state.startYear
    && Number(row.year) <= state.endYear);
}

function sumBy(records, groupFields, valueField) {
  const grouped = new Map();
  records.forEach((row) => {
    const keyValues = groupFields.map((field) => row[field]);
    const key = JSON.stringify(keyValues);
    const previous = grouped.get(key) || Object.fromEntries([...groupFields.map((field, index) => [field, keyValues[index]]), [valueField, 0]]);
    previous[valueField] += Number(row[valueField]) || 0;
    grouped.set(key, previous);
  });
  return [...grouped.values()];
}

function annualMetrics(records) {
  const annual = sumBy(records, ["year"], "production_tonnes").sort((a, b) => a.year - b.year);
  return annual.map((row) => {
    const sameYear = records.filter((record) => Number(record.year) === Number(row.year));
    row.area_ha = sameYear.reduce((total, record) => total + Number(record.area_ha), 0);
    row.yield_tonnes_per_ha = row.area_ha ? row.production_tonnes / row.area_ha : 0;
    return row;
  });
}

function aggregateState(records) {
  const totals = sumBy(records, ["state"], "production_tonnes");
  return totals.map((row) => {
    const stateRows = records.filter((record) => record.state === row.state);
    row.area_ha = stateRows.reduce((total, record) => total + Number(record.area_ha), 0);
    row.yield_tonnes_per_ha = row.area_ha ? row.production_tonnes / row.area_ha : 0;
    return row;
  });
}

function chartLayout(title = "", height = 285) {
  return {
    title: title ? { text: title, font: { family: "Manrope, sans-serif", size: 14, color: "#26372f" }, x: 0.02, y: 0.98 } : undefined,
    height,
    margin: { l: 48, r: 16, t: 16, b: 40 },
    paper_bgcolor: "rgba(0,0,0,0)",
    plot_bgcolor: "rgba(0,0,0,0)",
    font: { family: "DM Sans, sans-serif", size: 11, color: "#627067" },
    hoverlabel: { bgcolor: "#fff", font: { family: "DM Sans, sans-serif" } },
    showlegend: false,
    xaxis: { gridcolor: "#e6ebe5", zeroline: false, linecolor: "#dfe6df" },
    yaxis: { gridcolor: "#e6ebe5", zeroline: false, linecolor: "#dfe6df" },
  };
}

function drawChart(id, traces, layout = {}, config = {}) {
  const element = $(`#${id}`);
  if (!element || !window.Plotly) {
    if (element) element.textContent = "Chart library unavailable. Check your connection and reload.";
    return;
  }
  Plotly.react(element, traces, { ...chartLayout("", layout.height || 285), ...layout }, {
    responsive: true, displaylogo: false, modeBarButtonsToRemove: ["lasso2d", "select2d"], ...config,
  });
}

function updateTopbar(records) {
  const years = state.records.map((row) => Number(row.year)).filter(Number.isFinite);
  $("#hero-years").textContent = years.length ? `${Math.min(...years)}–${Math.max(...years)}` : "—";
  $("#hero-records").textContent = number.format(state.records.length);
  $("#source-short").textContent = state.source;
  $("#source-badge").textContent = state.isDemo ? "SYNTHETIC DEMO DATA" : "USER-UPLOADED DATA";
  $("#source-badge").classList.toggle("official", !state.isDemo);
  $("#global-notice").textContent = state.isDemo
    ? "DEMO DATA · These synthetic values demonstrate the analysis workflow and are not official agricultural statistics. Upload a verified dataset to analyze real records."
    : `USER DATA · ${state.records.length.toLocaleString("en-IN")} cleaned rows from ${state.source}. Verify units and source metadata before drawing conclusions.`;
  $("#method-source").textContent = state.source;
  $("#method-source-title").textContent = state.source;
  const details = [
    ["Records", number.format(state.records.length)],
    ["Coverage", years.length ? `${Math.min(...years)}–${Math.max(...years)}` : "—"],
    ["States", number.format(unique("state").length)],
    ["Crops", number.format(unique("crop").length)],
    ["Source status", state.isDemo ? "Synthetic; not official" : "Uploaded by user; not independently verified"],
  ];
  $("#source-details").innerHTML = details.map(([term, value]) => `<dt>${escapeHtml(term)}</dt><dd>${escapeHtml(value)}</dd>`).join("");
  $("#export-button").disabled = records.length === 0;
}

function kpi(label, value, unit) {
  return `<div class="kpi"><span class="kpi-label">${escapeHtml(label)}</span><strong class="kpi-value">${escapeHtml(value)}</strong><span class="kpi-unit">${escapeHtml(unit)}</span></div>`;
}

function insightItems(items) {
  const target = $("#overview-insights");
  target.innerHTML = items.length
    ? items.map((item, index) => `<div class="insight-item"><span class="insight-index">0${index + 1}</span><span>${escapeHtml(item)}</span></div>`).join("")
    : '<div class="inline-status">No records match the selected filters.</div>';
}

function makeInsights(records) {
  if (!records.length) return [];
  const states = aggregateState(records);
  const leader = [...states].sort((a, b) => b.yield_tonnes_per_ha - a.yield_tonnes_per_ha)[0];
  const findings = [`${leader.state} has the highest area-weighted yield in this selection (${decimal.format(leader.yield_tonnes_per_ha)} t/ha).`];
  const annual = annualMetrics(records);
  if (annual.length >= 2) {
    const first = annual[0];
    const last = annual.at(-1);
    const change = first.production_tonnes ? (last.production_tonnes / first.production_tonnes - 1) * 100 : null;
    if (change !== null) findings.push(`Production changed ${change >= 0 ? "+" : ""}${change.toFixed(1)}% between ${first.year} and ${last.year}.`);
    const shifts = annual.slice(1).map((row, index) => ({ year: row.year, growth: annual[index].production_tonnes ? (row.production_tonnes / annual[index].production_tonnes - 1) * 100 : null })).filter((row) => row.growth !== null);
    if (shifts.length) {
      const largest = shifts.reduce((best, row) => Math.abs(row.growth) > Math.abs(best.growth) ? row : best);
      findings.push(`The largest year-over-year movement was ${largest.growth >= 0 ? "+" : ""}${largest.growth.toFixed(1)}% in ${largest.year}.`);
    }
  }
  return findings;
}

function renderOverview(records) {
  const production = records.reduce((total, row) => total + Number(row.production_tonnes), 0);
  const area = records.reduce((total, row) => total + Number(row.area_ha), 0);
  const yieldValue = area ? production / area : 0;
  $("#overview-kpis").innerHTML = [
    kpi("Total production", number.format(production), "metric tonnes"),
    kpi("Cultivated area", number.format(area), "hectares"),
    kpi("Area-weighted yield", decimal.format(yieldValue), "tonnes / hectare"),
    kpi("States · crops", `${uniqueFrom(records, "state").length} · ${uniqueFrom(records, "crop").length}`, "in current selection"),
  ].join("");
  $("#overview-period").textContent = records.length ? `${Math.min(...records.map((row) => row.year))}–${Math.max(...records.map((row) => row.year))}` : "No matching records";
  const annual = annualMetrics(records);
  drawChart("overview-line", [{ x: annual.map((row) => row.year), y: annual.map((row) => row.production_tonnes), mode: "lines+markers", type: "scatter", line: { color: PALETTE[0], width: 3, shape: "spline" }, marker: { size: 6 }, fill: "tozeroy", fillcolor: "rgba(40,86,66,.09)", hovertemplate: "%{x}: %{y:,.0f} t<extra></extra>" }], { height: 300, margin: { l: 60, r: 12, t: 15, b: 38 }, xaxis: { title: "Year", gridcolor: "#e6ebe5" }, yaxis: { title: "Production (t)", gridcolor: "#e6ebe5", tickformat: ".2s" } });
  const top = aggregateState(records).sort((a, b) => b.production_tonnes - a.production_tonnes).slice(0, 8).reverse();
  drawChart("overview-states", [{ x: top.map((row) => row.production_tonnes), y: top.map((row) => row.state), type: "bar", orientation: "h", marker: { color: PALETTE[1] }, hovertemplate: "%{y}<br>%{x:,.0f} t<extra></extra>" }], { height: Math.max(280, top.length * 35), margin: { l: 130, r: 12, t: 10, b: 35 }, xaxis: { title: "Production (t)", gridcolor: "#e6ebe5", tickformat: ".2s" }, yaxis: { automargin: true, gridcolor: "transparent" } });
  insightItems(makeInsights(records));
}

function uniqueFrom(records, field) {
  return [...new Set(records.map((row) => row[field]).filter(Boolean))];
}

function renderStateComparison(records) {
  const measure = $("#state-metric").value;
  const labels = { production_tonnes: "Production (metric tonnes)", yield_tonnes_per_ha: "Area-weighted yield (tonnes / hectare)", area_ha: "Cultivated area (hectares)" };
  const ranking = aggregateState(records).sort((a, b) => b[measure] - a[measure]);
  $("#state-chart-title").textContent = labels[measure];
  const bars = [...ranking].reverse();
  drawChart("state-ranking", [{ x: bars.map((row) => row[measure]), y: bars.map((row) => row.state), type: "bar", orientation: "h", marker: { color: bars.map((_, index) => index === bars.length - 1 ? PALETTE[0] : "#98b39b") }, customdata: bars.map((row) => [row.production_tonnes, row.area_ha, row.yield_tonnes_per_ha]), hovertemplate: "%{y}<br>Rank value: %{x:,.2f}<br>Production: %{customdata[0]:,.0f} t<br>Area: %{customdata[1]:,.0f} ha<br>Yield: %{customdata[2]:.2f} t/ha<extra></extra>" }], { height: Math.max(360, Math.min(720, ranking.length * 28)), margin: { l: 138, r: 15, t: 10, b: 45 }, xaxis: { title: labels[measure], gridcolor: "#e6ebe5", tickformat: ".2s" }, yaxis: { automargin: true, gridcolor: "transparent" } });
  const years = uniqueFrom(records, "year").sort((a, b) => a - b);
  const states = uniqueFrom(records, "state");
  const traces = states.map((name, index) => {
    const series = years.map((year) => records.filter((row) => row.state === name && Number(row.year) === Number(year)).reduce((sum, row) => sum + Number(row.production_tonnes), 0));
    return { x: years, y: series, name, mode: "lines+markers", type: "scatter", line: { color: PALETTE[index % PALETTE.length], width: 2 }, marker: { size: 5 }, hovertemplate: `${escapeHtml(name)} · %{x}: %{y:,.0f} t<extra></extra>` };
  });
  drawChart("state-trend", traces, { height: 315, showlegend: true, legend: { orientation: "h", y: -0.24, font: { size: 9 } }, margin: { l: 60, r: 18, t: 10, b: 70 }, xaxis: { title: "Year", gridcolor: "#e6ebe5" }, yaxis: { title: "Production (t)", gridcolor: "#e6ebe5", tickformat: ".2s" } });
  $("#state-table").innerHTML = buildTable(ranking, [
    ["state", "State"], ["area_ha", "Area (ha)"], ["production_tonnes", "Production (t)"], ["yield_tonnes_per_ha", "Yield (t/ha)"],
  ], { area_ha: "number", production_tonnes: "number", yield_tonnes_per_ha: "decimal" });
}

function renderTrends(records) {
  const annual = annualMetrics(records);
  $("#trend-period").textContent = annual.length ? `${annual[0].year}–${annual.at(-1).year}` : "No matching records";
  const traces = [
    ["trend-production", "production_tonnes", "Production (t)", PALETTE[0], ".2s"],
    ["trend-yield", "yield_tonnes_per_ha", "Yield (t/ha)", PALETTE[1], ".2f"],
    ["trend-area", "area_ha", "Cultivated area (ha)", PALETTE[2], ".2s"],
  ];
  traces.forEach(([id, key, label, color, tickformat]) => drawChart(id, [{ x: annual.map((row) => row.year), y: annual.map((row) => row[key]), mode: "lines+markers", type: "scatter", line: { color, width: 3 }, marker: { size: 6 }, hovertemplate: `%{x}: %{y:,.2f}<extra></extra>` }], { height: id === "trend-area" ? 295 : 270, margin: { l: 65, r: 15, t: 12, b: 38 }, xaxis: { title: "Year", gridcolor: "#e6ebe5" }, yaxis: { title: label, tickformat, gridcolor: "#e6ebe5" } }));

  const seasonNames = uniqueFrom(records, "season").filter((season) => season !== "Not recorded");
  const seasonalSection = $("#season-chart-section");
  const seasonalEmpty = $("#season-empty");
  seasonalSection.hidden = seasonNames.length < 2;
  seasonalEmpty.hidden = seasonNames.length >= 2;
  if (seasonNames.length >= 2) {
    const seasons = seasonNames.map((season, index) => {
      const data = sumBy(records.filter((row) => row.season === season), ["year"], "production_tonnes").sort((a, b) => a.year - b.year);
      return { x: data.map((row) => row.year), y: data.map((row) => row.production_tonnes), name: season, mode: "lines+markers", type: "scatter", line: { color: PALETTE[index % PALETTE.length], width: 2 }, hovertemplate: `${escapeHtml(season)} · %{x}: %{y:,.0f} t<extra></extra>` };
    });
    drawChart("trend-season", seasons, { height: 300, showlegend: true, legend: { orientation: "h", y: -0.2 }, margin: { l: 65, r: 15, t: 10, b: 55 }, xaxis: { title: "Year", gridcolor: "#e6ebe5" }, yaxis: { title: "Production (t)", tickformat: ".2s", gridcolor: "#e6ebe5" } });
  }
  const findings = makeInsights(records);
  const changes = annual.slice(1).map((row, index) => ({ year: row.year, growth: annual[index].production_tonnes ? (row.production_tonnes / annual[index].production_tonnes - 1) * 100 : null })).filter((row) => row.growth !== null);
  if (changes.length >= 2) {
    const deviation = Math.sqrt(changes.reduce((sum, row) => sum + row.growth ** 2, 0) / changes.length);
    const unusual = changes.filter((row) => Math.abs(row.growth) > Math.max(10, deviation * 2));
    if (unusual.length) findings.push(`Large one-year movements, screened at more than max(10%, 2× the movement scale), appear in ${unusual.map((row) => row.year).join(", ")}. This flag does not explain why they occurred.`);
  }
  const target = $("#trend-insights");
  target.innerHTML = findings.length ? findings.map((item, index) => `<div class="insight-item"><span class="insight-index">0${index + 1}</span><span>${escapeHtml(item)}</span></div>`).join("") : '<div class="inline-status">No records match the selected filters.</div>';
}

function buildTable(rows, columns, formats = {}) {
  if (!rows.length) return '<p class="inline-status">No records to display.</p>';
  const header = columns.map(([, label]) => `<th>${escapeHtml(label)}</th>`).join("");
  const body = rows.map((row) => `<tr>${columns.map(([key]) => {
    const value = row[key];
    const format = formats[key];
    const rendered = format === "number" ? number.format(Number(value)) : format === "decimal" ? decimal.format(Number(value)) : value;
    return `<td>${escapeHtml(rendered)}</td>`;
  }).join("")}</tr>`).join("");
  return `<table><thead><tr>${header}</tr></thead><tbody>${body}</tbody></table>`;
}

function refresh() {
  if (!state.records.length) return;
  const records = selectedRecords();
  updateYearOutput();
  updateTopbar(records);
  const pageNames = { overview: ["OVERVIEW", "CropWise India", "A clearer view of crop performance across states, seasons, and time."], states: ["STATE COMPARISON", "State comparison", "Compare production, area, and yield across the selected regions."], trends: ["HISTORICAL TRENDS", "Historical trends", "Trace recorded changes without assuming a cause."], yield: ["YIELD LAB", "Yield lab", "Train, compare, and inspect historical yield models."], explorer: ["DATA EXPLORER", "Data explorer", "Inspect a dataset or upload records for this session."], methodology: ["METHODOLOGY", "Methodology & sources", "Understand the data, methods, and limits behind each result."] };
  const [crumb, title, description] = pageNames[state.page];
  $("#breadcrumb-page").textContent = crumb;
  $("#page-title").textContent = title;
  $("#page-description").textContent = description;
  $(".hero-copy h1").textContent = title;
  $(".hero-copy > p:last-child").textContent = description;
  $$(".page-view").forEach((view) => view.classList.toggle("active", view.dataset.view === state.page));
  $$(".nav-link").forEach((button) => button.classList.toggle("active", button.dataset.page === state.page));
  if (state.page === "overview") renderOverview(records);
  if (state.page === "states") renderStateComparison(records);
  if (state.page === "trends") renderTrends(records);
  if (state.page === "explorer") renderExplorer();
  if (state.page === "methodology") updateTopbar(records);
}

function renderExplorer() {
  const records = state.records;
  const rawRows = state.rawUpload?.rawRows || records;
  const rawColumns = state.rawUpload?.columns || (records.length ? Object.keys(records[0]) : []);
  const missing = rawColumns.map((column) => ({ column, count: rawRows.filter((row) => row[column] === null || row[column] === undefined || String(row[column]).trim() === "").length }));
  const duplicateCount = rawRows.length - new Set(rawRows.map((row) => JSON.stringify(row))).size;
  $("#dataset-summary").innerHTML = [
    kpi("Rows", number.format(rawRows.length), "before cleaning"),
    kpi("Columns", number.format(rawColumns.length), "source fields"),
    kpi("Exact duplicates", number.format(duplicateCount), "source rows"),
    kpi("Missing cells", number.format(missing.reduce((sum, item) => sum + item.count, 0)), "source fields"),
  ].join("");
  const previewRows = records.slice(0, 100);
  const columns = ["state", "crop", "season", "year", "area_ha", "production_tonnes", "yield_tonnes_per_ha"].filter((key) => records.length && key in records[0]).map((key) => [key, ({ area_ha: "Area (ha)", production_tonnes: "Production (t)", yield_tonnes_per_ha: "Yield (t/ha)" })[key] || key]);
  $("#data-preview").innerHTML = buildTable(previewRows, columns, { area_ha: "number", production_tonnes: "number", yield_tonnes_per_ha: "decimal" });
  if (records.length > 100) $("#data-preview").insertAdjacentHTML("beforeend", '<p class="period-label">Showing the first 100 cleaned rows.</p>');
  $("#data-schema").innerHTML = buildTable(missing.map((item) => ({ ...item, type: inferType(rawRows, item.column) })), [["column", "Column"], ["type", "Type"], ["count", "Missing"]], { count: "number" });
  const numeric = ["year", "area_ha", "production_tonnes", "yield_tonnes_per_ha"].filter((key) => records.length && key in records[0]);
  const descriptions = numeric.flatMap((field) => {
    const values = records.map((row) => Number(row[field])).filter(Number.isFinite).sort((a, b) => a - b);
    if (!values.length) return [];
    return [{ field, count: values.length, mean: values.reduce((sum, value) => sum + value, 0) / values.length, min: values[0], median: values[Math.floor(values.length / 2)], max: values.at(-1) }];
  });
  $("#data-description").innerHTML = buildTable(descriptions, [["field", "Field"], ["count", "Count"], ["mean", "Mean"], ["min", "Min"], ["median", "Median"], ["max", "Max"]], { count: "number", mean: "decimal", min: "decimal", median: "decimal", max: "decimal" });
  $("#clear-upload").hidden = state.isDemo;
  $("#upload-warnings").innerHTML = [...state.uploadWarnings, ...(records.length > 100 ? ["The preview is capped at 100 rows; filtered CSV export includes all matching records."] : [])].map((warning) => `<div class="insight-item"><span class="insight-index">!</span><span>${escapeHtml(warning)}</span></div>`).join("");
}

function inferType(rows, key) {
  const sample = rows.find((row) => row[key] !== null && row[key] !== undefined && String(row[key]).trim() !== "")?.[key];
  if (sample === undefined) return "empty";
  return Number.isFinite(Number(String(sample).replaceAll(",", ""))) ? "numeric" : "text";
}

function toCsv(rows) {
  if (!rows.length) return "";
  const columns = [...new Set(rows.flatMap((row) => Object.keys(row)))];
  const cell = (value) => {
    const text = value === null || value === undefined ? "" : String(value);
    return /[",\r\n]/.test(text) ? `"${text.replaceAll('"', '""')}"` : text;
  };
  return [columns.map(cell).join(","), ...rows.map((row) => columns.map((key) => cell(row[key])).join(","))].join("\r\n");
}

function downloadFile(name, content, type) {
  const url = URL.createObjectURL(new Blob([content], { type }));
  const anchor = document.createElement("a");
  anchor.href = url;
  anchor.download = name;
  anchor.click();
  URL.revokeObjectURL(url);
}

function setupModelInputs() {
  const states = unique("state");
  const crops = unique("crop");
  const select = (id, values) => { $(id).innerHTML = values.map((value) => `<option value="${escapeHtml(value)}">${escapeHtml(value)}</option>`).join(""); };
  select("#scenario-state", states);
  select("#scenario-crop", crops);
  const seasonsForCrop = () => uniqueFrom(state.records.filter((row) => row.crop === $("#scenario-crop").value), "season");
  const updateSeasons = () => select("#scenario-season", seasonsForCrop());
  $("#scenario-crop").onchange = updateSeasons;
  updateSeasons();
  const maxYear = Math.max(...state.records.map((row) => Number(row.year)));
  $("#scenario-year").min = maxYear;
  $("#scenario-year").value = Math.min(2100, maxYear + 1);
}

function scenarioPayload() {
  const area = Number($("#scenario-area").value);
  const year = Number($("#scenario-year").value);
  if (!Number.isFinite(area) || area <= 0) throw new Error("Area must be greater than zero.");
  if (!Number.isInteger(year) || year < 1900 || year > 2100) throw new Error("Enter a year from 1900 to 2100.");
  return { state: $("#scenario-state").value, crop: $("#scenario-crop").value, season: $("#scenario-season").value, area_ha: area, year };
}

function drawModelResults(result) {
  state.modelResults = result;
  $("#model-output").hidden = false;
  $("#split-note").textContent = `${result.split_note} ${number.format(result.rows_used)} usable rows.`;
  $("#model-metrics").innerHTML = buildTable(result.metrics, [["Model", "Model"], ["MAE (t/ha)", "MAE (t/ha)"], ["RMSE (t/ha)", "RMSE (t/ha)"], ["R²", "R²"]], { "MAE (t/ha)": "decimal", "RMSE (t/ha)": "decimal", "R²": "decimal" });
  const best = result.best_model;
  const predictions = result.predictions;
  const colors = uniqueFrom(predictions, "crop");
  const scatter = colors.map((crop, index) => {
    const group = predictions.filter((row) => row.crop === crop);
    return { x: group.map((row) => row.actual), y: group.map((row) => row[best]), mode: "markers", type: "scatter", name: crop, marker: { color: PALETTE[index % PALETTE.length], size: 7, opacity: .72 }, customdata: group.map((row) => [row.state, row.year]), hovertemplate: `${escapeHtml(crop)}<br>Actual: %{x:.2f}<br>Predicted: %{y:.2f}<br>%{customdata[0]} · %{customdata[1]}<extra></extra>` };
  });
  const extent = Math.max(...predictions.flatMap((row) => [Number(row.actual), Number(row[best])]).filter(Number.isFinite));
  scatter.push({ x: [0, extent], y: [0, extent], mode: "lines", type: "scatter", name: "Ideal", line: { color: "#7f8c81", dash: "dash", width: 1 } });
  drawChart("model-scatter", scatter, { height: 300, showlegend: true, legend: { orientation: "h", y: -0.25, font: { size: 9 } }, margin: { l: 60, r: 15, t: 10, b: 70 }, xaxis: { title: "Actual yield (t/ha)", gridcolor: "#e6ebe5" }, yaxis: { title: "Predicted yield (t/ha)", gridcolor: "#e6ebe5" } });
  const residualTraces = colors.map((crop, index) => {
    const group = predictions.filter((row) => row.crop === crop);
    return { x: group.map((row) => row[best]), y: group.map((row) => Number(row[best]) - Number(row.actual)), mode: "markers", type: "scatter", name: crop, marker: { color: PALETTE[index % PALETTE.length], size: 7, opacity: .72 }, customdata: group.map((row) => [row.state, row.year]), hovertemplate: `${escapeHtml(crop)}<br>Predicted: %{x:.2f}<br>Residual: %{y:.2f}<br>%{customdata[0]} · %{customdata[1]}<extra></extra>` };
  });
  residualTraces.push({ x: [0, extent], y: [0, 0], mode: "lines", type: "scatter", name: "Zero error", line: { color: "#7f8c81", dash: "dash", width: 1 } });
  drawChart("model-residuals", residualTraces, { height: 300, showlegend: true, legend: { orientation: "h", y: -0.25, font: { size: 9 } }, margin: { l: 60, r: 15, t: 10, b: 70 }, xaxis: { title: "Predicted yield (t/ha)", gridcolor: "#e6ebe5" }, yaxis: { title: "Residual (t/ha)", gridcolor: "#e6ebe5" } });
}

async function callModel(includeScenario) {
  const status = $("#model-status");
  const button = includeScenario ? $("#estimate-button") : $("#run-model");
  const oldText = button.textContent;
  button.disabled = true;
  button.textContent = "Training…";
  status.textContent = "Training baseline and regression models, then scoring held-out years…";
  showError("");
  try {
    const payload = { records: state.records };
    if (includeScenario) payload.scenario = scenarioPayload();
    const result = await requestJson("/api/model", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(payload) });
    drawModelResults(result);
    if (includeScenario) {
      $("#scenario-result").hidden = false;
      $("#scenario-result").textContent = `Estimated yield: ${decimal.format(result.scenario_yield_tonnes_per_ha)} tonnes / hectare · ${result.best_model}`;
    }
    status.textContent = `Best held-out MAE: ${result.best_model}. Historical evaluation only; inspect the split and metrics before interpreting the scenario.`;
  } catch (error) {
    showError(error.message);
    status.textContent = "Model evaluation could not be completed for this dataset.";
  } finally {
    button.disabled = false;
    button.textContent = oldText;
  }
}

async function loadUpload(file) {
  if (!window.Papa) throw new Error("CSV parser did not load. Check your connection and try again.");
  if (file.size > 3_500_000) throw new Error("CSV is too large for a serverless request. Keep the file under 3.5 MB.");
  $("#upload-status").textContent = "Reading and validating CSV…";
  const parsed = await new Promise((resolve, reject) => Papa.parse(file, { header: true, skipEmptyLines: true, dynamicTyping: false, complete: resolve, error: reject }));
  if (parsed.errors.length) throw new Error(parsed.errors[0].message);
  const rawRows = parsed.data;
  if (!rawRows.length) throw new Error("This CSV has no data rows.");
  if (rawRows.length > 5000) throw new Error("Uploads are limited to 5,000 rows.");
  const result = await requestJson("/api/normalize", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ records: rawRows }) });
  state.records = result.records;
  state.source = `Uploaded: ${file.name}`;
  state.isDemo = false;
  state.rawUpload = { rawRows, columns: parsed.meta.fields || Object.keys(rawRows[0] || {}) };
  state.uploadWarnings = result.warnings;
  resetSelection();
  setupModelInputs();
  $("#upload-status").textContent = `${number.format(rawRows.length)} source rows read; ${number.format(state.records.length)} valid rows retained.`;
  showError("");
  refresh();
}

function exportFilteredCsv() {
  const rows = selectedRecords();
  if (!rows.length) return showError("No matching rows are available to export.");
  downloadFile("cropwise_filtered.csv", toCsv(rows), "text/csv;charset=utf-8");
}

function downloadReport() {
  const records = selectedRecords();
  const production = records.reduce((sum, row) => sum + Number(row.production_tonnes), 0);
  const area = records.reduce((sum, row) => sum + Number(row.area_ha), 0);
  const filterSummary = `States: ${[...state.selectedStates].join(", ")}; crops: ${[...state.selectedCrops].join(", ")}; seasons: ${[...state.selectedSeasons].join(", ")}; years: ${state.startYear}–${state.endYear}`;
  const lines = ["# CropWise India · Filtered analysis", `Source: ${state.source}`, `Filters: ${filterSummary}`, `Production: ${production.toFixed(2)} metric tonnes`, `Cultivated area: ${area.toFixed(2)} hectares`, `Area-weighted yield: ${area ? (production / area).toFixed(4) : "n/a"} tonnes/hectare`, "", "## Calculated findings", ...makeInsights(records).map((finding) => `- ${finding}`), "", "## Model evaluation", ...(state.modelResults ? state.modelResults.metrics.map((row) => `- ${row.Model}: MAE ${Number(row["MAE (t/ha)"]).toFixed(4)} t/ha; RMSE ${Number(row["RMSE (t/ha)"]).toFixed(4)} t/ha; R² ${row["R²"] === null ? "n/a" : Number(row["R²"]).toFixed(4)}`) : ["Run the yield model to include evaluation metrics."]), "", "Descriptive findings do not establish causation. Demo data, when active, are synthetic and not official statistics."];
  downloadFile("cropwise_analysis.md", lines.join("\n"), "text/markdown;charset=utf-8");
}

function setupEvents() {
  $$(".nav-link").forEach((button) => button.addEventListener("click", () => { state.page = button.dataset.page; refresh(); window.scrollTo({ top: 0, behavior: "smooth" }); }));
  $("#reset-filters").addEventListener("click", () => { resetSelection(); refresh(); });
  $("#export-button").addEventListener("click", exportFilteredCsv);
  $("#state-metric").addEventListener("change", () => renderStateComparison(selectedRecords()));
  $("#run-model").addEventListener("click", () => callModel(false));
  $("#estimate-button").addEventListener("click", () => callModel(true));
  $("#csv-upload").addEventListener("change", async (event) => {
    const file = event.target.files?.[0];
    if (!file) return;
    try { await loadUpload(file); } catch (error) { $("#upload-status").textContent = "CSV could not be loaded."; showError(error.message); }
    event.target.value = "";
  });
  $("#clear-upload").addEventListener("click", async () => {
    try {
      const demo = await requestJson("/api/data/demo");
      state.records = demo.records;
      state.source = demo.source;
      state.isDemo = true;
      state.rawUpload = null;
      state.uploadWarnings = [];
      resetSelection();
      setupModelInputs();
      $("#upload-status").textContent = "Returned to the synthetic demonstration dataset.";
      refresh();
    } catch (error) { showError(error.message); }
  });
  $("#export-button").setAttribute("aria-label", "Download filtered CSV");
  $("#state-metric").value = "production_tonnes";
  $("#run-model").title = "Fit models and evaluate on held-out years";
  const reportButton = document.createElement("button");
  reportButton.type = "button";
  reportButton.className = "quiet-button";
  reportButton.textContent = "↓ Analysis report";
  reportButton.addEventListener("click", downloadReport);
  const heading = $("[data-view=overview] .section-heading");
  heading.append(reportButton);
}

async function start() {
  setupEvents();
  try {
    const payload = await requestJson("/api/data/demo");
    state.records = payload.records;
    state.source = payload.source;
    state.isDemo = true;
    resetSelection();
    setupModelInputs();
    refresh();
  } catch (error) {
    showError(`The CropWise API could not be reached: ${error.message}`);
    $("#source-short").textContent = "API unavailable";
  }
}

start();