# CropWise India

CropWise India is a responsive agricultural analytics web app. Vercel serves the static interface from its CDN and runs the Python data/model API as a FastAPI function.

## Data status

The default dataset is deterministic **synthetic demonstration data** for interface and workflow testing. It is not official Indian agricultural statistics and must not be cited as real-world findings.

The Directorate of Economics & Statistics (DES), Department of Agriculture & Farmers Welfare, publishes official estimates and links to the Area Production & Yield information system. The APY portal inspected for this project presents a sign-in page, so no state-level official dataset is bundled and this app does not claim automatic government-data refresh. Upload a verified, unit-documented CSV before drawing agricultural conclusions.

Official references:

- DES: <https://desagri.gov.in/>
- DES Area Production & Yield information system: <https://data.desagri.gov.in/>
- Open Government Data Platform India: <https://www.data.gov.in/>
- India Meteorological Department: <https://mausam.imd.gov.in/>

## Deploy to Vercel

Deployment requires access to a Vercel account and a Git provider, or the Vercel CLI. This workspace is not authenticated to a Vercel account, so the final account-side deploy and production URL must be completed by the project owner.

### Git integration

1. Push the project root to a GitHub, GitLab, or Bitbucket repository.
2. In the Vercel dashboard, choose **Add New → Project** and import that repository.
3. Keep the project root as the root directory. Vercel detects the FastAPI `app` in `app.py`, reads `requirements.txt`, and serves assets in `public/` from its CDN.
4. Deploy. The `.python-version` file selects Python 3.12. No environment variables or API keys are required.

### Vercel CLI

From the project directory in PowerShell:

```powershell
npm install --global vercel
vercel login
vercel
```

Follow the prompts to link or create a Vercel project. The CLI prints a preview `*.vercel.app` URL. When ready for the production alias, run:

```powershell
vercel --prod
```

### Local development

Requires Python 3.12 (or a compatible local Python) and Node.js/npm.

```powershell
python -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install -r requirements.txt
npm install --global vercel
vercel dev
```

Open the local URL printed by Vercel, usually <http://localhost:3000>. For a direct FastAPI check, run `python -m uvicorn app:app --reload` from the project root.

## CSV format and uploads

Required fields are state, crop, year, area, and production. Common variants such as `State_Name`, `Crop_Year`, `Area`, and `Production` are recognized. Area must be in **hectares** and production in **metric tonnes**. Optional fields are season and yield; yield is derived as production divided by area when absent. Verify the source documentation and convert units before upload.

The browser parses the CSV, then the API validates and normalizes it. Invalid required rows are removed with warnings, and the original file is unchanged. Uploads are not persisted: they live in browser memory and are sent to a stateless function. Limits are 5,000 rows and 3.5 MB per CSV request. Filtered CSV and Markdown analysis downloads are generated in the browser. For larger or shared data, add object storage/database persistence and access controls.

## Analysis and model

Production and area are summed within filters; aggregate yield is total production divided by total area. Seasonal comparisons appear only when multiple recorded seasons are present. Trend and outlier notes are descriptive and do not establish causes.

The median dummy baseline is compared with Linear Regression and Random Forest Regression. Features are state, crop, season, year, and area; same-record production is excluded to prevent leakage into the yield target. When at least three years are available, the latest years form a chronological test set. MAE, RMSE, and R² are calculated from those held-out predictions. The selected regression is then retrained on the full dataset for a scenario estimate. Historical metrics do not guarantee future forecast accuracy. Rainfall, temperature, soil, and irrigation inputs are not included.

## Project layout

```text
cropwise-india/
  app.py                 FastAPI endpoints for Vercel Functions
  cropwise/
    data.py              CSV normalization and synthetic demo records
    modeling.py          Evaluation and scenario estimation
  public/
    index.html           Dashboard page structure
    styles.css           Responsive styling
    app.js               Filters, charts, upload, and downloads
  vercel.json            Function configuration
  .python-version        Python runtime for Vercel
  requirements.txt
```