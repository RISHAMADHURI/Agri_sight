from __future__ import annotations

import os
from functools import lru_cache
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel, Field

from cropwise.data import make_demo_data, normalize_dataset
from cropwise.modeling import estimate_yield, evaluate_models

app = FastAPI(title="CropWise India API", version="1.0.0")
MAX_RECORDS = 5_000


class DatasetRequest(BaseModel):
    records: list[dict[str, Any]] = Field(min_length=1, max_length=MAX_RECORDS)


class Scenario(BaseModel):
    state: str
    crop: str
    season: str
    year: int = Field(ge=1900, le=2100)
    area_ha: float = Field(gt=0, le=100_000_000)


class ModelRequest(DatasetRequest):
    scenario: Scenario | None = None


@lru_cache(maxsize=1)
def _demo_records() -> tuple[dict, ...]:
    return tuple(make_demo_data().to_dict(orient="records"))


def _normalize(records: list[dict[str, Any]]) -> tuple[pd.DataFrame, list[str]]:
    if len(records) > MAX_RECORDS:
        raise HTTPException(status_code=413, detail=f"Upload is limited to {MAX_RECORDS:,} rows per request.")
    try:
        frame, warnings = normalize_dataset(pd.DataFrame.from_records(records))
    except (ValueError, TypeError) as error:
        raise HTTPException(status_code=422, detail=str(error)) from error
    return frame, warnings


@app.get("/api/health")
def health() -> dict[str, str]:
    return {"status": "ok", "service": "CropWise India"}


@app.get("/api/data/demo")
def demo_data() -> dict:
    return {
        "source": "Synthetic demonstration data (not official statistics)",
        "records": list(_demo_records()),
    }


@app.post("/api/normalize")
def normalize_upload(request: DatasetRequest) -> dict:
    records, warnings = _normalize(request.records)
    return {"records": records.to_dict(orient="records"), "warnings": warnings}


@app.post("/api/model")
def model_results(request: ModelRequest) -> dict:
    records, warnings = _normalize(request.records)
    try:
        results = evaluate_models(records)
    except ValueError as error:
        raise HTTPException(status_code=422, detail=str(error)) from error

    response = {
        "metrics": results["metrics"].replace({np.nan: None}).to_dict(orient="records"),
        "predictions": results["predictions"].replace({np.nan: None}).to_dict(orient="records"),
        "best_model": results["best_model"],
        "split_note": results["split_note"],
        "rows_used": results["rows_used"],
        "warnings": warnings,
    }
    if request.scenario:
        scenario = request.scenario
        response["scenario_yield_tonnes_per_ha"] = estimate_yield(
            results,
            scenario.state,
            scenario.crop,
            scenario.season,
            scenario.year,
            scenario.area_ha,
        )
    return response


if not os.getenv("VERCEL"):
    from fastapi.staticfiles import StaticFiles

    app.mount("/", StaticFiles(directory=Path(__file__).parent / "public", html=True), name="frontend")